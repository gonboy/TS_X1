This is the well known FatFS from http://elm-chan.org/fsw/ff/00index_e.html
